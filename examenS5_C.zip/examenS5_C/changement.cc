#include "changement.hh"


void changement::appliquer(banque &bank)
{
    auto compte = bank.accesCompte(numeroCompte());
    _ancienProprio = compte->proprietaire();
    compte->setProprietaire(_nouveauProprio);
}

void changement::annuler(banque &bank)
{
    auto compte = bank.accesCompte(numeroCompte());

    compte->setProprietaire(_ancienProprio);
}
