#include <iostream>

#include "compte.hh"
#include "compte_courant.hh"
#include "compte_livret.hh"
#include "compte_exception.hh"
#include "banque.hh"
#include "operation.hh"
#include "virement.hh"
#include "versement.hh"
#include "changement.hh"

using namespace std;

int main()
{
    std::unique_ptr<compte_courant> MaFrench_A= std::make_unique<compte_courant>(300,"Aristote",-500);
    std::unique_ptr<compte_livret>  Livret= std::make_unique<compte_livret>(3000,"Vi");
     compte_livret Livret_A(200,"CR7");
     compte_livret Livret_B(200,"CR88");
     compte_courant MaFrench(4000,"Aris",-500);

     MaFrench.verseInterets();
     Livret_A.verseInterets();
     std::cout<< MaFrench<< std::endl;
     std::cout << Livret_A<<std::endl;



    std::cout<< *MaFrench_A <<std::endl;
    banque LaBanquePostale;
    LaBanquePostale.ajout(std::move(MaFrench_A));
    LaBanquePostale.ajout(std::move(Livret));


    //LaBanquePostale.saisiretrait();
//    versement ver1 (1,200);
//    ver1.appliquer(LaBanquePostale);
//    changement prop(1,"Quang");



    return 0;
}
