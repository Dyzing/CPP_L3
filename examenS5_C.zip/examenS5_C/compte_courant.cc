#include "compte_courant.hh"


float compte_courant::decouvert() const
{
    return _decouvert;
}

compte_courant::compte_courant(int montant, std::string proprio, float _min):compte(montant,proprio),_decouvert(_min)
{

}

float compte_courant::taux() const
{
    return 0;
}

float compte_courant::montantmin() const
{
    return _decouvert;
}

void compte_courant::verser(float montant)
{
    float m = getMontant();
        m += montant;
        setMontant(m);
}

void compte_courant::retirer(float montant)
{
        float m = getMontant();
        if (m-montant < _decouvert) throw compte_exception("retrait non autorise ! decouvert depasse");
        else {
            m=m-montant;
            setMontant(m);
        }
}

std::ostream &operator<< (std::ostream & os, compte_courant & C){
    os << "compte courant-"<<C.getNumero()<<"-"<<C.proprietaire()<<"-Montant : "<<C.getMontant()<<"-Decouvert autorise : "<<C.decouvert();
    return os;
}
