#pragma once
#include "compte.hh"

class compte_livret : public compte
{
private:
    static float _taux;
public:
    compte_livret(int montant,std::string proprio);
    float taux() const override;
    float montantmin() const override;
    void verser(float montant) override;
    void retirer(float montant) override;
    void modifie_taux(int taux_){
        _taux = taux_;
    }
    std::unique_ptr<compte> clone() const override{
        return std::make_unique<compte_livret>(*this);
    }
};
std::ostream &operator<< (std::ostream & os, compte_livret & C);
