#include "virement.hh"

void virement::appliquer(banque  & bank)
{
    auto compte = bank.accesCompte(numeroCompte());
    auto compte2 = bank.accesCompte(_destinataire);
    try {
        compte->retirer(_montantVirement);


    }catch (compte_exception const & e) {
    std::cout << e.message()<< std::endl;


    }
    try {
        compte2->verser(_montantVirement);


    }catch (compte_exception const & e) {
    std::cout << e.message()<< std::endl;
    }
}

void virement::annuler(banque &bank)
{
    auto compte = bank.accesCompte(numeroCompte());
    auto compte2 = bank.accesCompte(_destinataire);
    try {
        compte2->retirer(_montantVirement);


    }catch (compte_exception const & e) {
    std::cout << e.message()<< std::endl;


    }
    try {
        compte->verser(_montantVirement);


    }catch (compte_exception const & e) {
    std::cout << e.message()<< std::endl;
    }
}
