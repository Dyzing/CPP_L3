#pragma once
#include "operation.hh"
#include "banque.hh"
class versement : public operation
{
private:
    int _montantVersement;
public:
    versement(int numero,float montant):operation(numero),_montantVersement(montant){}
    void appliquer(banque &bank) override;
    void annuler(banque  & bank) override;
};

