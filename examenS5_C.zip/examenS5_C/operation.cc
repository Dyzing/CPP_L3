#include "operation.hh"


int operation::numeroCompte() const
{
    return _numeroCompte;
}
