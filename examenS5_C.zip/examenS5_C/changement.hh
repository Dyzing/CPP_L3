#pragma once
#include "operation.hh"
class changement : public operation
{
private:
    std::string _nouveauProprio;
    std::string _ancienProprio;
public:

    changement(int num,std::string nouveauProprio):operation(num),_nouveauProprio(nouveauProprio){

    }
    void appliquer(banque &bank) override;
    void annuler(banque &bank) override;
};
