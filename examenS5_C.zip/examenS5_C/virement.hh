#pragma once
#include "operation.hh"


class virement : public operation
{
private:
    float _montantVirement;
    int _destinataire;
public:
    virement(int num,float montant,int dest):operation(num),_montantVirement(montant),_destinataire(dest){}
    void appliquer(banque &bank) override;
    void annuler(banque &bank) override;
};

