#include "versement.hh"


void versement::appliquer(banque  & bank)
{
    auto compte = bank.accesCompte(numeroCompte());
    try {
        compte->verser(_montantVersement);

    }catch (compte_exception const & e) {
    std::cout << e.message()<< std::endl;

    //saisiretrait();
    }
}

void versement::annuler(banque &bank)
{
    auto compte = bank.accesCompte(numeroCompte());
    try {
        compte->retirer(_montantVersement);

    }catch (compte_exception const & e) {
        std::cout << e.message()<< std::endl;
    }
}
