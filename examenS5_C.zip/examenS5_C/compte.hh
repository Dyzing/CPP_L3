#pragma once
#include "compte_exception.hh"
#include <string>
#include <iostream>
#include <memory>

class compte
{
private:
    int _numero;
    float _montant;

    std::string _proprietaire;


    static int num;

public:
    compte(float montant,std::string const & proprio);
    compte(compte const & C){
        _numero = C._numero;
        _montant=C._montant;
        _proprietaire=C._proprietaire;
    }
    virtual ~compte() =default;
    virtual std::unique_ptr<compte> clone() const =0;
    std::string proprietaire() const;
    float getMontant() const;
    int getNumero();

    virtual float taux () const =0;
    virtual float montantmin() const = 0;
    virtual void verser(float montant) =0;
    virtual void retirer(float montant)=0;


    void setMontant(float montant);
    void verseInterets();
    void setProprietaire(const std::string &proprietaire);
};
