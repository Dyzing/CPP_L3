#include "compte_exception.hh"


std::string compte_exception::message() const
{
    return _message;
}

compte_exception::compte_exception(std::string mess):exception(),_message(mess)
{

}

