#include "compte_livret.hh"
#include "compte_exception.hh"

float compte_livret::_taux =1;

compte_livret::compte_livret(int montant, std::string proprio):compte(montant,proprio)
{

}

float compte_livret::taux() const
{
    return _taux;
}

float compte_livret::montantmin() const
{
    return 0;
}

void compte_livret::verser(float montant)
{
    float m = getMontant();
        if (m+montant>30000) throw compte_exception("limite depassee");
        else {
            m += montant;
            setMontant(m);
        }
}

void compte_livret::retirer(float montant)
{
    float m = getMontant();
        if (m-montant<0) throw compte_exception("pas de fond suffisant");
        else {
            m -= montant;
            setMontant(m);
        }
}
std::ostream &operator<< (std::ostream & os, compte_livret & C){
    os << "compte Livret-"<<C.getNumero()<<"-"<<C.proprietaire()<<"-Montant : "<<C.getMontant();
    return os;
}
