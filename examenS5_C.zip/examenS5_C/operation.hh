#pragma once
#include "banque.hh"

class operation
{
private:
    int _numeroCompte;
public:
    operation(int num):_numeroCompte(num){}
    virtual void appliquer(banque & bank) = 0;
    virtual void annuler(banque  & bank) =0;
    int numeroCompte() const;
};

