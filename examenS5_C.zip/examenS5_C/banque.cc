#include "banque.hh"


banque::banque(const banque &B)
{

    for (auto const & i : B._lesComptes){
        _lesComptes.push_back(i->clone());
    }
}

banque &banque::operator=(const banque &s)
{
    for (auto & p : s._lesComptes)
    _lesComptes.push_back(p->clone());

    return *this;
}

void banque::ajout(std::unique_ptr<compte> compte)
{
    _lesComptes.push_back(std::move(compte));
}


compte *banque::accesCompte(int num) const{

    for (auto & p : _lesComptes) {
        if(p->getNumero() == num) return p.get();
    }
    return nullptr;
}

//const compte &banque::accesCompte(int num) const{

//    for (auto & p : _lesComptes) {
//        if(p->getNumero() == num) return *p;
//    }

//}

void banque::saisiretrait()
{
    int num;
    int montant;
    std::cout<<"Entrez un numero de compte"<<std::endl;
    std::cin>>num;

    auto compte_a =accesCompte(num);
    while(compte_a==nullptr)
    {
        std::cout<<"compte introuvable entrez un numero de compte correct"<<std::endl;
        std::cin>>num;
        compte_a = accesCompte(num);
    }



    std::cout<<"Entrez un montant"<<std::endl;
    std::cin>>montant;

    try {
        compte_a->retirer(montant);
        std::cout<<"operation effectue solde : "<< compte_a->getMontant()<<std::endl;
    } catch (compte_exception const & e) {
            std::cout << e.message() <<"! veuillez recommencer"<< std::endl;

            saisiretrait();
    }

}
