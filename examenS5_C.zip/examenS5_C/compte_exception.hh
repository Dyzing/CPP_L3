#pragma once
#include <exception>
#include <string>
#include <iostream>

class compte_exception : public std::exception
{
private:
    std::string _message;
public:
    compte_exception(std::string mess);

    std::string message() const;
};
