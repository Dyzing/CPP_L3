#pragma once
#include "compte.hh"
#include "compte_exception.hh"

class compte_courant : public compte
{
private:
    float _decouvert;
public:
    compte_courant(int montant,std::string proprio,float _min);
    float taux() const override;

    float montantmin() const override;
    void verser(float montant) override;
    void retirer(float montant) override;
    float decouvert() const;
    std::unique_ptr<compte> clone() const override{
        return std::make_unique<compte_courant>(*this);
    }
};
std::ostream &operator<< (std::ostream & os, compte_courant & C);
