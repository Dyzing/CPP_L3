#include "compte.hh"
int compte::num = 0;
std::string compte::proprietaire() const
{
    return _proprietaire;
}

float compte::getMontant() const
{
    return _montant;
}

int compte::getNumero()
{
    return _numero;
}

void compte::setMontant(float montant)
{
    _montant = montant;
}

void compte::verseInterets()
{
    float t= taux()/100;
    try{
    verser(getMontant()*t);

    } catch (compte_exception const & e) {
        float m= getMontant();
        m += getMontant()*taux()/100;
        setMontant(m);
}

}

void compte::setProprietaire(const std::string &proprietaire)
{
    _proprietaire = proprietaire;
}

compte::compte(float montant, const std::string &proprio):_numero(++num),_montant(montant),_proprietaire(proprio){}
