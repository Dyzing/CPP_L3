#pragma once
#include <memory>
#include "compte.hh"
#include "compte_courant.hh"
#include "compte_livret.hh"
#include <vector>

class banque
{
private:
   std::vector<std::unique_ptr<compte>> _lesComptes;
public:
    banque()=default;
    banque(banque const & B);
    banque & operator=(banque const & s);
    ~banque() =default;
    void ajout(std::unique_ptr<compte> compte);
    std::vector<std::unique_ptr<compte> > lesComptes() const;
    compte * accesCompte (int num) const;
    //compte const & accesCompte(int num) const;
    void saisiretrait();
    void affiche() const;
};
