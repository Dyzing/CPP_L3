#include "societe.hh"

societe::societe()
{

}
