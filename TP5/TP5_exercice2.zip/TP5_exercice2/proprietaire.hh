#pragma once
#include <iostream>



class proprietaire
{
public:
    proprietaire();
    virtual std::string nom() const =0;
    virtual std::string type() const =0;
    virtual std::string adresse() const =0;
    virtual std::string etiquetteexpedition() const =0;

private:
   std::string _nom;
   std::string _type;
   std::string _adresse;

};

