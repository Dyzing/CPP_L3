#pragma once
#include "proprietaire.hh"
#include <iostream>

class couple : public proprietaire
{
public:
    couple();
    std::string nom() const override;
};

