#include "personne.hh"

personne::personne()
{

}

std::string personne::nom() const
{
    return "Personne";
}
