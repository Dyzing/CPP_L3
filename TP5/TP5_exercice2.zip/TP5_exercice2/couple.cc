#include "couple.hh"

couple::couple()
{

}
