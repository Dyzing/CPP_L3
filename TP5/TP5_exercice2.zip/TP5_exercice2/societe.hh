#pragma once
#include "proprietaire.hh"
#include <iostream>

class societe : public proprietaire
{
public:
    societe();
    std::string nom() const override;
};

