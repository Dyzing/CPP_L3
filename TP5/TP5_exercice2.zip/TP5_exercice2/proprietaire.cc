#include "proprietaire.hh"

proprietaire::proprietaire()
{

}
