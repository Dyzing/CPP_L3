#pragma once
#include "proprietaire.hh"
#include <iostream>


class personne : public proprietaire
{
public:
    personne();
    std::string nom() const override;
};
