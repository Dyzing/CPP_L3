#include <iostream>
#include "proprietaire.hh"
#include <memory>
#include "couple.hh"
#include "personne.hh"
#include "societe.hh"

using namespace std;

int main()
{
    return 0;
}
