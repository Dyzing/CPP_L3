#include "monexception.h"

std::string  const & monexception::message_exception() const
{
    return _message;
}
