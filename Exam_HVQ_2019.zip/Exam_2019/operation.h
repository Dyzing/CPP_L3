#pragma once


#include <iostream>
#include "compte.h"
#include "compte_courant.h"
#include "compte_livrets.h"
#include "banque.h"


class operation
{
private:
    unsigned int _numMemoire;
public:
    operation(unsigned int numMemoire);
    virtual void appliquer(banque & bank)=0;
    virtual void annuler(banque & bank)=0;
    unsigned int getteur_numMemoire() const;
};


class versement : public operation
{
private:
    float _montantMemoire;
public:
    versement(unsigned int numMemoire, float montantMemoire);
    void appliquer(banque &bank) override;
    void annuler(banque &bank) override;
};



class virement : public operation
{
private:
    float _montantVersement;
    unsigned int _numDestination;
public:
    virement(unsigned int numMemoire, float montantVersement, unsigned int numDestination);
    void appliquer(banque &bank) override;
    void annuler(banque &bank) override;
};


class changement : public operation
{
private:
    std::string _newProprietaire;
public:
    changement(unsigned int numMemoire ,std::string newProprietaire);
    void appliquer(banque &bank) override;
    void annuler(banque &bank) override;
};
