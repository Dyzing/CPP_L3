#pragma once


#include <iostream>
#include "compte.h"
#include "monexception.h"

class compte_livrets : public compte
{
public:
    compte_livrets(float montant, std::string proprietaire);
    float taux() const override;
    void verser(float m) override;
    void retirer(float m) override;

    std::unique_ptr<compte> clone() const override {
        return std::make_unique<compte_livrets>(*this);
    }
};


std::ostream & operator<<(std::ostream & os, compte_livrets const & cc);
