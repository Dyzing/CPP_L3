#pragma once
#ifndef BANQUE_H
#define BANQUE_H

#include "compte.h"
#include "compte_courant.h"
#include "compte_livrets.h"
#include <iostream>
#include <vector>
#include <memory>

class banque
{
private:
   std::vector<std::unique_ptr<compte>> _contenu;
public:
    banque()=default;
    ~banque()=default;
    banque(banque const & b);
    void ajoute(std::unique_ptr<compte> c);
    std::unique_ptr<compte> accescompte(unsigned int m);
    void saisieretrait();

};

#endif // BANQUE_H
