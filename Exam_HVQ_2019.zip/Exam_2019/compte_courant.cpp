#include "compte_courant.h"

compte_courant::compte_courant(float montant, std::string proprietaire)
    : compte(montant,proprietaire)
{

}

std::ostream & operator<<(std::ostream & os, compte_courant const & cc)
{
    os << "Compte Courant - " << cc.getteur_numero() << " - " << cc.getteur_proprietaire() << " - Montant: " << cc.getteur_montant();
    return os;
}
