#include <iostream>
#include "compte.h"
#include "compte_courant.h"
#include "compte_livrets.h"
#include "monexception.h"
#include "banque.h"

#include "operation.h"

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    compte_courant cc1(0,"A");
    compte_livrets cl1(30000,"B");

    std::cout << "Compte Courant: " << cc1.taux() << endl;
    std::cout << "Compte Livret: " << cl1.taux() << endl;


    /*
    cc1.verser(100); //200
    cl1.verser(300); //500

    std::cout << "Montant Courant: " << cc1.getteur_montant() << endl;
    std::cout << "Montant Livret: " << cl1.getteur_montant() << endl;

    cc1.retirer(50); //150
    cl1.retirer(100); //400

    std::cout << "Montant Courant: " << cc1.getteur_montant() << endl;
    std::cout << "Montant Livret: " << cl1.getteur_montant() << endl;
    */
    /*
    try {
        cc1.retirer(100); //donner exception
    } catch (monexception const & e) {
        std::cout << e.message_exception() << endl;
    }

    std::cout << "Montant Courant: " << cc1.getteur_montant() << endl;

    try {
        cl1.verser(100); //donner exception
    } catch (monexception const & e) {
        std::cout << e.message_exception() << endl;
    }

    std::cout << "Montant Livret: " << cl1.getteur_montant() << endl;
    */

   // cc1.verserinterets();
    //std::cout << "Montant Courant: " << cc1.getteur_montant() << endl;

   // cl1.verserinterets();
   // std::cout << "Montant Livret: " << cl1.getteur_montant() << endl;

    std::cout << cc1 << endl;
    std::cout << cl1 << endl;

    banque b1;
    auto cc2 = std::make_unique<compte_courant>(5000,"vivi");
    b1.ajoute(std::move(cc2));

    auto cl2 = std::make_unique<compte_livrets>(10000,"Aris");
    b1.ajoute(std::move(cl2));

   //auto b = b1.accescompte(3); //il faut tester avec un compte qui a un vecteur càd cc2 et cl2
    //std::cout << b->getteur_montant() << endl;

   // b1.saisieretrait(3,300);

   // b1.saisieretrait();


    //versement v1(3,200);
    //v1.appliquer(b1);

    changement ch1(4,"Aristote");
    ch1.appliquer(b1);

  //auto b = b1.accescompte(3); //pour vérifier si un montane de 300 est bien ajoute dans cc2 ou non ?
  //std::cout << b->getteur_montant() << endl; //Mais il y un soucis: 2 pointeurs pointent sur cc2

    return 0;
}
