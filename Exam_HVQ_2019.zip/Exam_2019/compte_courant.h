#pragma once


#include <iostream>
#include "compte.h"
#include "monexception.h"
#include <memory>
#include <vector>

class compte_courant : public compte
{
public:
    compte_courant(float montant, std::string proprietaire);
    std::unique_ptr<compte> clone() const override {
        return std::make_unique<compte_courant>(*this);
    }
};

std::ostream & operator<<(std::ostream & os, compte_courant const & cc);
