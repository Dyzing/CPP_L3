#include "banque.h"

banque::banque(banque const & b)
{
    for (auto const & c : b._contenu)
        _contenu.push_back(c->clone());
}

void banque::ajoute(std::unique_ptr<compte> c)
{
    _contenu.push_back(std::move(c));
}

std::unique_ptr<compte> banque::accescompte(unsigned int num) {
    for (auto i = _contenu.begin();i!=_contenu.end();++i){

            if((*i)->getteur_numero()==num)
            {
                return std::move((*i));
            }
    }
    return nullptr;
}

void banque::saisieretrait()
{

   int num;
   float montant;
   std::cout << "Entrez un numero d'un compte: " ; //Etape 1 : Demande un numero d'un compte
   std::cin >> num;

   if (num <=0) // si ce numero est negatif -> redemander un autre numero
   {
       std::cout << "Un numro d'un compte doit etre positif" << std::endl;
       saisieretrait();
   }

   else //sinon on accéder à ce compte
   {
       auto i = accescompte(num); //accéder au compte
       if (i != nullptr) //verifier si ce compte existe ? si oui on demande le montant
       {
           std::cout << "Entrez un montant: ";
           std::cin >> montant;
           if (montant < 0)     //si ce montant est negatif -> recommence
           {
               std::cout << "Un montant ne peux pas etre negatif" << std::endl;
               //i.reset();
               saisieretrait();
           }
           else     //si le montant est bon, on verifie la somme dans le compte
           {
                if (i->getteur_montant() <= 0)  //si ce n'est pas assez => affichier le message et recommence
                {
                  std::cout << "Le montant n'est pas assez pour retirer" << std::endl;
                  //i.reset();
                  saisieretrait();
                }
                else        //si c'est assez on effectue l'operation
                {
                    i->retirer(montant);
                    std::cout << "Operation effectue" << std::endl;
                }
            }
       }
       else //si le compte n'existe pas => affiche le message
       {
           std::cout << "Compte introuvé" << std::endl;
          saisieretrait();
       }
   }
}

