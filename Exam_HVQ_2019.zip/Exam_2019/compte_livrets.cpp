#include "compte_livrets.h"

compte_livrets::compte_livrets(float montant, std::string proprietaire)
    : compte(montant, proprietaire)
{

}

float compte_livrets::taux() const
{
    return 1.0;
}

void compte_livrets::verser(float m)
{
    if (getteur_montant() >= 30000)
        throw monexception(1,"Depasser");
    else
    {
        float new_montant = getteur_montant() + m;
        setteur_montant(new_montant);
    }
}

void compte_livrets::retirer(float m)
{
    if (getteur_montant() < 0)
        throw monexception(2, "Pas assez");
    else {
        float new_montant = getteur_montant() - m;
        setteur_montant(new_montant);
    }
}

std::ostream & operator<<(std::ostream & os, compte_livrets const & cc)
{
    os << "Compte Courant - " << cc.getteur_numero() << " - " << cc.getteur_proprietaire() << " - Montant: " << cc.getteur_montant();
    return os;
}
