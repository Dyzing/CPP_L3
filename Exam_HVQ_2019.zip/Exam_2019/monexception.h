#pragma once
#ifndef MONEXCEPTION_H
#define MONEXCEPTION_H
#include <exception>
#include <iostream>


class monexception : public std::exception
{
public:
    int _num;
    std::string _message;
public:
    monexception(int num, std::string message): _num(num), _message(message) {}
    std::string const &  message_exception() const ;
};

#endif // MONEXCEPTION_H
