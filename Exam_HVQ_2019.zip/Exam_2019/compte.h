#pragma once
#include <iostream>
#include "monexception.h"
#include <memory>

class compte
{
private:
    unsigned int _numero;
    float _montant;
    std::string _proprietaire;
    std::string _oldProprietaire;
    static unsigned int compteur;

public:
    compte(float montant, std::string proprietaire);
    virtual ~compte()=default;
    virtual std::unique_ptr<compte> clone() const=0;

    unsigned int getteur_numero() const;
    float getteur_montant() const;
    void setteur_montant(float m);
    std::string getteur_proprietaire() const;
    void setteur_proprietaire(std::string newPro);
    std::string getteur_oldproprietaire() const;
    virtual float taux() const;
    virtual void verser(float m);
    virtual void retirer(float m);
    void verserinterets();


};


