#include "operation.h"

operation::operation(unsigned int numMemoire)
    : _numMemoire(numMemoire)
{}

versement::versement(unsigned int numMemoire,float montantMemoire)
    : operation(numMemoire), _montantMemoire(montantMemoire)
{}

virement::virement(unsigned int numMemoire, float montantVersement, unsigned int numDestination)
    : operation(numMemoire), _montantVersement(montantVersement), _numDestination(numDestination)
{}

changement::changement(unsigned int numMemoire ,std::string newProprietaire)
    : operation(numMemoire), _newProprietaire(newProprietaire)
{}

unsigned int operation::getteur_numMemoire() const
{
    return _numMemoire;
}

/*
void operation::appliquer(banque & bank)
{
    bank.accescompte(_numMemoire);
}
*/

void versement::appliquer(banque & bank)
{
    unsigned int ind = getteur_numMemoire();
    auto i = bank.accescompte(ind);
    i->verser(_montantMemoire);
    std::cout << "Operation Effectue" << std::endl; //pour savoir si ça passe bien ou non ?
}

void virement::appliquer(banque &bank)
{
    unsigned int ind = getteur_numMemoire();
    auto i1 = bank.accescompte(ind);
    i1->retirer(_montantVersement);
    auto i2 = bank.accescompte(_numDestination);
    i2->verser(_montantVersement);
    std::cout << "Operation Effectue" << std::endl;
}

void changement::appliquer(banque &bank)
{
    unsigned int ind = getteur_numMemoire();
    auto i = bank.accescompte(ind);
    i->setteur_proprietaire(_newProprietaire);
    std::cout << "Operation Effectue" << std::endl;
}

void versement::annuler(banque &bank)
{
    unsigned int ind = getteur_numMemoire();
    auto i = bank.accescompte(ind);
    i->retirer(_montantMemoire);
      std::cout << "Operation Effectue" << std::endl;
}

void virement::annuler(banque &bank)
{
    unsigned int ind = getteur_numMemoire();
    auto i1 = bank.accescompte(ind);
    i1->verser(_montantVersement);
    auto i2 = bank.accescompte(_numDestination);
    i2->retirer(_montantVersement);
    std::cout << "Operation Effectue" << std::endl;
}

void changement::annuler(banque &bank)
{
    unsigned int ind = getteur_numMemoire();
    auto i = bank.accescompte(ind);
    i->setteur_proprietaire(i->getteur_oldproprietaire());
    std::cout << "Operation Effectue" << std::endl;
}
