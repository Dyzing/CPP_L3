#include "compte.h"

unsigned int compte::compteur=1;

compte::compte(float montant, std::string proprietaire)
    : _numero(compteur++), _montant(montant), _proprietaire(proprietaire)
{

}

unsigned int compte::getteur_numero() const
{
    return _numero;
}

float compte::getteur_montant() const
{
    return _montant;
}

std::string compte::getteur_proprietaire() const
{
    return _proprietaire;
}

void compte::setteur_montant(float m)
{
    _montant = m;
}

void compte::setteur_proprietaire(std::string newPro)
{
    _oldProprietaire = _proprietaire;
    _proprietaire = newPro;
}

std::string compte::getteur_oldproprietaire() const
{
    return _oldProprietaire;
}

float compte::taux() const
{
    return 0.0;
}

void compte::verser(float m)
{
    _montant = _montant + m;
}

void compte::retirer(float m)
{
    if (_montant <= 0)
        throw monexception(2, "Pas Assez");
    else {
        _montant = _montant - m;
    }
}

void compte::verserinterets()
{
    float montan_interet = _montant * (taux()/100);
    setteur_montant((_montant = _montant + montan_interet));
}


